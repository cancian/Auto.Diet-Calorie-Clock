﻿//##//////////////////##//
//## DYNAMIC HANDLERS ##//
//##//////////////////##//
$(document).on("pageload", function (evt) {
	// PREVENT++ //
	if ((evt.target.id) > 0) {
		var tgt = "#" + evt.target.id;
	} else {
		var tgt = "";
	}
	var entryReturn = false;
	//#///////////#//
	//# HOLD EDIT #//
	//#///////////#//
	var holdStart;
	var deMove = 0;
	var cancelEdit = 0;
	$("#entryList div" + tgt).on("longhold", function (evt) {
		clearTimeout(holdStart);
		deMove = 0;
		if (!$("#entryList div" + tgt + " .entriesTitle").html()) {
			return;
		}
		if (!$(this).hasClass("longHold")) {
			return;	
		}
		if ($("#editableInput").is(":visible")) {
			return;
		}
		entryReturn = true;
		deKeyboard = 1;
		if (cancelEdit == 0) {
			getEntryEdit($(this).attr('id'));
		}
	});
	var isHoldMove = isMobile.MSApp() ? '' : touchmove;
	$("#entryList div, #appContent").on(isHoldMove + ' mouseleave mouseout mouseup ' + touchend, function (evt) {
		deMove++;
		if (deMove > 40 || (isMobile.Android() && deMove > 1)) {
			cancelEdit = 1;
			clearTimeout(holdStart);
			$('.longHold').removeClass('longHold');
		}
	});
	$("#appContent").scroll(function () {
		deKeyboard = 1;
		deMove++;
		//cancelEdit = 1;
	});
	//////////////////
	// FORCE RETURN //
	//////////////////
	$("#entryList div" + tgt).on(touchend, function (evt) {
		deMove = 0;
		clearTimeout(holdStart);
		$('.longHold').removeClass('longHold');
	});

	$("#entryList div" + tgt).on(touchstart, function (evt) {
		deMove = 0;
		clearTimeout(holdStart);
		var holdThis = this;
		if (!$('#entryList div').is(':animated') && !$('.editableInput').is(':visible') && !$('#editable').is(':visible') && !$('#appStatusFix').hasClass('open') && !$(".delete").hasClass("active")) {
			holdStart = setTimeout(function() {
				if (!$('#entryList div').is(':animated') && !$('.editableInput').is(':visible') && !$('#editable').is(':visible') && !$('#appStatusFix').hasClass('open') && !$(".delete").hasClass("active")) {
					$(holdThis).addClass('longHold');
					entryReturn = true;
				}
			},200);
		}
		if ($('#entryTime').is(':focus')) {
			entryReturn = true;
		}
		if ($('#entryBody').is(':focus')) {
			entryReturn = true;
		}
		deKeyboard = 0;
		deMove = 0;
		cancelEdit = 0;
	});
	$("#entryList div" + tgt).on(tap, function (event) {
		//$("#entryList div" + tgt).swipe({tap:function(event) {
		event.preventDefault();
		// clear hold		
		clearTimeout(holdStart);
		$('.longHold').removeClass('longHold');
		//////////////
		// TAP DATE //
		//////////////
		if (event.target.id.length == 14 && !$('#entryList div').is(':animated') && !$('.editableInput').is(':visible')) {
			$("#" + event.target.id).html(dtFormat(Number(event.target.id.replace("t", ""))));
			setTimeout(function () {
				$("#" + event.target.id).html(dateDiff(event.target.id.replace("t", ""), (new Date()).getTime()));
			}, 2000);
			entryReturn = true;
		}
		//////////////////
		// TAP DIV EDIT //
		//////////////////
		//no delete
		if (!$('.active').hasClass('open')) {
			$('.active').addClass('busy');
			$('.active').removeClass('open');
			$('.active').on(transitionend, function (e) {
				$('.active').removeClass('busy');
			});
			$('.active').removeClass('active');
			if ($('.delete').hasClass('busy')) {
				return;
			}
			if ($('#kcalsDiv').is(':visible')) {
				return;
			}
			if ($('#entryList div').is(':animated') || $('.editableInput').is(':visible') || $('#entryBody').is(':animated') || entryReturn == true || deKeyboard != 0 || blockModal == true) {
				entryReturn = false;
				return;
			}
			////////////////////////
			// START ENTRY UPDATE //
			////////////////////////
			if (!$('.editableInput').is(':visible')) {
				if (!$(this).has('input').length) {
					var value = trim($('.entriesBody', this).text());
					var kcals = $('.entriesTitle', this).html();
					var timedBlur = new Date().getTime();
					$('.entriesTitle', this).attr('id', 'kcalsDiv');
					var input = $('<input/>', {
							'type' : 'text',
							'id' : 'editableInput',
							'class' : 'editableInput',
							'value' : value,
							//ONCHANGE HANDLER
							blur : function () {
								////////////////
								// TIMED BLUR //
								////////////////
								var nowBlur = new Date().getTime();
								if (isMobile.Android() || isMobile.FirefoxOS()) {
									if (nowBlur - timedBlur < 600) {
										var blurVal = $("#editableInput").val();
										$("#editableInput").focus();
										//$("#editableInput").val('');
										setTimeout(function () {
											$("#editableInput").focus();
											//$("#editableInput").val(blurVal);
										}, 0);
										return;
									}
								}
								var new_value = $(this).val();
								//VALIDATE
								if (this.value == "") {
									if (Number(document.getElementById('kcalsDiv').innerHTML) > 0) {
										new_value = LANG.FOOD[lang];
									} else if (Number(document.getElementById('kcalsDiv').innerHTML) < 0) {
										new_value = LANG.EXERCISE[lang];
									} else {
										new_value = "";
									}
								}
								$(this).replaceWith(new_value);
								$('#kcalsAdjust').remove();
								$('#kcalsDiv').parent("div").removeClass("editing");
								$('#kcalsDiv').parent("div").animate({
									"backgroundColor" : "#fff"
								}, 500, function (evt) {
									eP = 0;
									deKeyboard = (new Date()).getTime();
									return false;
								});
								$('#kcalsDiv').removeAttr('id');
								$("#sliderBlock").fadeOut(500);
								clearRepeaterBlock();
								//whitegap fix
								setTimeout(function () {
									updateEntriesSum();
								}, 0);
								kickDown();
								return false;
							},
							change : function () {
								//save changes
								var editableValue = $("#editableInput").val().split("  ").join(" ").split("  ").join(" ").split("  ").join(" ");
								saveEntry({
									body : editableValue,
									id : $(this).closest('div').data("id")
								});
								//set blur
								if (!$("#entryList div").is(':animated')) {
									$("#editableInput").blur();
								}
							}
						});
					//start edit
					$('.entriesBody', this).empty();
					$('.entriesBody', this).html(input);
					$('.entriesBody', this).after('<p id="kcalsAdjust">\
						<span id="adjustNegBlock"><span id="adjustNeg"></span></span>\
						<span id="adjustPosBlock"><span id="adjustPos"></span></span>\
						</p>');
					$("#editableInput").focus();
					///////////////////////
					// RESET ENTRY VALUE //
					///////////////////////
					$("#kcalsDiv").off(touchstart);
					$("#kcalsDiv").on(touchstart, function (evt) {
						evt.preventDefault();
						timedBlur = new Date().getTime() - 6 * 1000;
						//no reset block
						if (!$(this).parent('div').hasClass("editing")) {
							return;
						}
						var thisRowId = $(this).closest('div').data("id");
						//INTOTHEVOID
						function intoTheVoid(button) {
							//ON CONFIRM
							timedBlur = new Date().getTime();
							if (button == 1) {
								$("#" + thisRowId + " " + ".entriesTitle").html("0");
								$("#" + thisRowId + " " + ".entriesTitle").css("color", "#333");
								//save
								saveEntry({
									title : '0',
									id : thisRowId
								});
								updateTimer();
							}
							return false;
						}
						//SHOW DIALOG
						appConfirm(LANG.RESET_ENTRY_TITLE[lang], LANG.ARE_YOU_SURE[lang], intoTheVoid, LANG.OK[lang], LANG.CANCEL[lang]);
						return false;
					});
					/////////////////////
					// POSITIVE ADJUST //
					/////////////////////
					var adjustPosBlockSave;
					$("#adjustPosBlock").on(touchstart, function (evt) {
						evt.preventDefault();
						//prevent android click-blur
						timedBlur = new Date().getTime();
						$(this).addClass("activeBlock");
						if (Number(document.getElementById('kcalsDiv').innerHTML) <= 9999) {
							//first click 9999
							if (Number(document.getElementById('kcalsDiv').innerHTML) == -9999) {
								document.getElementById('kcalsDiv').innerHTML = -9975;
							} else {
								document.getElementById('kcalsDiv').innerHTML = Number(document.getElementById('kcalsDiv').innerHTML) + (1);
							}
							//limit 9999
							if (Number(document.getElementById('kcalsDiv').innerHTML) >= 9999) {
								document.getElementById('kcalsDiv').innerHTML = 9999;
							}
							if (Number(document.getElementById('kcalsDiv').innerHTML) >= 0) {
								document.getElementById('kcalsDiv').style.color = '#333';
							}
							//save value
							var idVal = $('#kcalsDiv').parent('div').data("id");
							var titleVal = document.getElementById('kcalsDiv').innerHTML;
							var bodyVal = document.getElementById('editableInput').value;
							clearTimeout(adjustPosBlockSave);
							adjustPosBlockSave = setTimeout(function () {
									saveEntry({
										title : titleVal,
										body : bodyVal,
										id : idVal
									});
									updateTimer();
								}, 450);
						}
						return false;
					});
					/////////////////////
					// NEGATIVE ADJUST //
					/////////////////////
					var adjustNegBlockSave;
					$("#adjustNegBlock").on(touchstart, function (evt) {
						evt.preventDefault();
						//prevent android click-blur
						timedBlur = new Date().getTime();
						$(this).addClass("activeBlock");
						if (Number(document.getElementById('kcalsDiv').innerHTML) >= -9999) {
							//first click 9999
							if (Number(document.getElementById('kcalsDiv').innerHTML) == 9999) {
								document.getElementById('kcalsDiv').innerHTML = 9975;
							} else {
								document.getElementById('kcalsDiv').innerHTML = Number(document.getElementById('kcalsDiv').innerHTML) - (1);
							}
							//limit 9999
							if (Number(document.getElementById('kcalsDiv').innerHTML) < -9999) {
								document.getElementById('kcalsDiv').innerHTML = -9999;
							}
							if (Number(document.getElementById('kcalsDiv').innerHTML) < 0) {
								document.getElementById('kcalsDiv').style.color = '#C00';
							}
							//save value
							var idVal = $('#kcalsDiv').parent('div').data("id");
							var titleVal = document.getElementById('kcalsDiv').innerHTML;
							var bodyVal = document.getElementById('editableInput').value;
							clearTimeout(adjustNegBlockSave);
							adjustNegBlockSave = setTimeout(function () {
									saveEntry({
										title : titleVal,
										body : bodyVal,
										id : idVal
									});
									updateTimer();
								}, 450);
						}
						return false;
					});
					///////////////////////
					// POSITIVE REPEATER //
					///////////////////////
					function clearRepeaterBlock() {
						clearTimeout(pressTimerNeg);
						clearTimeout(pressTimerPos);
						clearInterval(pressRepeatNeg);
						clearInterval(pressRepeatPos);
					}
					///////////////
					// AUTOCLEAR //
					///////////////
					$("#adjustPosBlock,#adjustNegBlock").on(touchend + " mouseout mouseup mouseleave", function (evt) {
						evt.preventDefault();
						$(".activeBlock").removeClass("activeBlock");
						clearRepeaterBlock();
					});
					//
					var pressTimerPos;
					var pressRepeatPos;
					$("#adjustPosBlock").on(touchend, function (evt) {
						evt.preventDefault();
						clearRepeaterBlock();
					});
					$("#adjustPosBlock").on(touchstart, function (evt) {
						evt.preventDefault();
						clearRepeaterBlock();
						pressTimerPos = setTimeout(function () {
								pressRepeatPos = setInterval(function () {
										//ACTION
										if (Number(document.getElementById('kcalsDiv').innerHTML) <= 9999) {
											//first click 9999
											if (Number(document.getElementById('kcalsDiv').innerHTML) == -9999) {
												document.getElementById('kcalsDiv').innerHTML = -9975;
											} else {
												document.getElementById('kcalsDiv').innerHTML = Number(document.getElementById('kcalsDiv').innerHTML) + (1);
											}
											//limit 9999
											if (Number(document.getElementById('kcalsDiv').innerHTML) >= 9999) {
												document.getElementById('kcalsDiv').innerHTML = 9999;
											}
											if (Number(document.getElementById('kcalsDiv').innerHTML) >= 0) {
												document.getElementById('kcalsDiv').style.color = '#333';
											}
											//save value
											var idVal = $('#kcalsDiv').parent('div').data("id");
											var titleVal = document.getElementById('kcalsDiv').innerHTML;
											var bodyVal = document.getElementById('editableInput').value;
											clearTimeout(adjustPosBlockSave);
											adjustPosBlockSave = setTimeout(function () {
													saveEntry({
														title : titleVal,
														body : bodyVal,
														id : idVal
													});
													updateTimer();
												}, 450);
										}
										return false;
									}, 25);
							}, 400);
					});
					///////////////////////
					// NEGATIVE REPEATER //
					///////////////////////
					var pressTimerNeg;
					var pressRepeatNeg;
					$("#adjustNegBlock").on(touchend, function (evt) {
						evt.preventDefault();
						clearRepeaterBlock();
					});
					$("#adjustNegBlock").on(touchstart, function (evt) {
						evt.preventDefault();
						clearRepeaterBlock();
						pressTimerNeg = setTimeout(function () {
								pressRepeatNeg = setInterval(function () {
										//ACTION
										if (Number(document.getElementById('kcalsDiv').innerHTML) >= -9999) {
											//first click 9999
											if (Number(document.getElementById('kcalsDiv').innerHTML) == 9999) {
												document.getElementById('kcalsDiv').innerHTML = 9975;
											} else {
												document.getElementById('kcalsDiv').innerHTML = Number(document.getElementById('kcalsDiv').innerHTML) - (1);
											}
											//limit 9999
											if (Number(document.getElementById('kcalsDiv').innerHTML) < -9999) {
												document.getElementById('kcalsDiv').innerHTML = -9999;
											}
											if (Number(document.getElementById('kcalsDiv').innerHTML) < 0) {
												document.getElementById('kcalsDiv').style.color = '#C00';
											}
											//save value
											var idVal = $('#kcalsDiv').parent('div').data("id");
											var titleVal = document.getElementById('kcalsDiv').innerHTML;
											var bodyVal = document.getElementById('editableInput').value;
											clearTimeout(adjustNegBlockSave);
											adjustNegBlockSave = setTimeout(function () {
													saveEntry({
														title : titleVal,
														body : bodyVal,
														id : idVal
													});
													updateTimer();
												}, 450);
										}
										return false;
									}, 25);
							}, 400);
					});
					//prevent empty list highlight
					if (!isNaN($(this).closest("div").attr("id"))) {
						var editableValue = $("#editableInput").val();
						if (editableValue == LANG.FOOD[lang] || editableValue == LANG.EXERCISE[lang]) {
							$("#editableInput").val('');
						}
						//remove double spaces
						$("#editableInput").val($("#editableInput").val().split("  ").join(" ").split("  ").join(" ").split("  ").join(" "));
						// FOCUS, THEN SET VALUE
						//$("#editableInput").select();
						$("#editableInput").focus();
						$(this).closest("div").animate({
							"backgroundColor" : "#ffffcc"
						}, 600);
						$(this).closest("div").addClass("editing");
						$("#sliderBlock").remove();
						$("#entryListForm").prepend("<div id='sliderBlock'></div>");
						//blur block
						$("#sliderBlock").on(touchstart, function (evt) {
							evt.preventDefault();
							evt.stopPropagation();
							if (!$("#entryList div").is(':animated')) {
								$("#editableInput").blur();
							}
						});
					}
				}
			}
			//////////////////////
			// END ENTRY UPDATE //
			//////////////////////
		}
	});
	//#///////////////#//
	//# IOS ROW SWIPE #//
	//#///////////////#//
	var swippen;
	$("#entryList div" + tgt).swipe({
		swipe : function (event, direction) {
			swippen = this;
			if (direction == 'left' || direction == 'right') {
				//HIDE ACTIVE
				if (!$('.delete').hasClass('busy')) {
					$('.active').addClass('busy');
					$('.active').removeClass('open');
					$('.active').on(transitionend, function (evt) {
						$('.active').removeClass('busy');
					});
					$('.active').removeClass('active');
				}
				//SHOW
				if (!$('#entryList div:animated').length > 0 && !$('.delete').hasClass('busy') && !$('.delete').hasClass('busy') && !$('.editableInput').is(':visible') && !$('#editable').is(':visible') && !$('.editableInput').is(':focus') && !$('#entryBody').is(':focus') && !$('#entryTime').is(':focus')) {
					$('.delete', swippen).addClass('busy');
					setTimeout(function () {
						$('.delete', swippen).addClass('active');
						$('.delete', swippen).addClass('open');
						$('.delete', swippen).on(transitionend, function (evt) {
							$('.delete').removeClass('busy');
						});
						//ffos
						setTimeout(function () {
							$('.delete').removeClass('busy');
						}, 200);
					}, 0);
				}
			}
		}
	});
	$("#entryList div").swipe("option", "threshold", 32);
	$("#entryList div").swipe("option", "allowPageScroll", "vertical");
	/////////////////////
	// STOP ENTRY EDIT //
	/////////////////////
	$("#appHeader,#entryListForm,#go,#sliderBlock,#entryList div,#entryListBottomBar").on(touchstart, function (evt) {
		if (!$('.editableInput').is(':visible')) {
			return;
		}
		if ($('.editableInput').is(':visible') && ($("#editableInput").is(":focus") || isMobile.Windows())) {
			//dismiss protection
			//if($("#entryList div" + tgt).is(':animated')) { return; }
			//ALLOW ENTRY INPUT RETINA FOCUS
			//evt.preventDefault();
			evt.stopPropagation();
			//ID MATCH
			if (!$("#entryList div").is(':animated')) {
				if ($(this).attr("id") != $("#editableInput").closest("div").attr("id")) {
					$("#editableInput").blur();
					evt.preventDefault();
					evt.stopPropagation();
				}
			}
		}
	});
	//wrapper click
	$("#entryListWrapper").on(touchstart, function (evt) {
		if ($('.editableInput').is(':visible')) {
			//ALLOW ENTRY INPUT RETINA FOCUS
			//evt.preventDefault();
			//evt.stopPropagation();
		}

		if (evt.target.id == "entryListWrapper") {
			if (!$("#entryList div").is(':animated')) {
				$("#editableInput").blur();
				//rekeyboarding on entrywrapper tap dismiss
				if (isMobile.iOS()) {
					//evt.preventDefault();
					//evt.stopPropagation();
					$("#entryListForm").prepend("<div id='sliderBlock'></div>");
					$("#sliderBlock").fadeOut(700, function (evt) {
						$("#sliderBlock").remove();
					});
				}
				//whitegap mitigation
				if (isMobile.Android() && !$('.active').hasClass('open')) {
					return false;
				}
				//evt.preventDefault();
			}
		}
	});
	/////////////////
	// GLOBAL HIDE //
	/////////////////
	$("#appHeader,#entryListForm,#go,#sliderBlock,#editablediv,#entryListWrapper").on(tap + " swipeLeft swipeRight", function (evt) {
		if (!isMobile.Android()) {
			evt.preventDefault();
		}
		if (!$('.active').hasClass('busy')) {
			$('.active').addClass('busy');
			$('.active').removeClass('open');
			$('.active').on(transitionend, function (e) {
				$('.active').removeClass('busy');
			});
			$('.active').removeClass('active');
		}
	});
	//////////////
	// SPAN TAP //
	//////////////
	var delGesture = isMobile.FirefoxOS() ? touchend : tap;
	$('div span.delete', this).on(delGesture, function (evt) {
		//evt.preventDefault();
		$(this).parent('div').hide();
		//UPDATE DB
		deleteEntry({
			id : $(this).parent('div').data("id"),
			published : $(this).parent('div').attr("name")
		});
		//REMOVE CLICKED
		$(this).parent('div').remove();
		updateTimer();
		updateEntriesTime();
		updateEntriesSum();
		//SCROLLBAR UPDATE
		//clearTimeout(niceTimer);
		//niceTimer = setTimeout(niceResizer, 200);
		//IF LAST ROW
		if ($('#entryList .entryListRow').length == 0) {
			$('#entryList').html('<div id="noEntries"><span>' + LANG.NO_ENTRIES[lang] + '</span></div>');
			updateTimer();
			return false;
		}
		//force error
		//kickDown();
		clearTimeout(niceTimer);
		niceTimer = setTimeout(function () {
				niceResizer();
				return false;
			}, 100);
		return false;
	});
	//////#//
}); //#//
//////#//
//#//////////////////////#//
//# DYNAMIC HANDLERS 2.0 #//
//#//////////////////////#//
$(document).on("pageReload", function (evt) {
	evt.preventDefault();
	//PREVENT DOUBLE LOAD
	if($('#pageSlideFood').hasClass("busy") && $('#pageSlideFood').hasClass('open')) {
		return;	
	} else {
		$("#pageSlideFood").remove();
	}
	if($("#pageSlideFood").length) {
		if($("#pageSlideFood").is(":animated")) {
			return;
		} else {
			$("#pageSlideFood").remove();
		}
	}
	//evt.stopPropagation();
	//not while editing ~
	if (!$('#entryList div').is(':animated') && !$('.editableInput').is(':visible') && !$('#editable').is(':visible') && !$('#appStatusFix').hasClass('open')) {
		//NO SWIPE OVERLAP
		if (!$('.active').hasClass('open')) {
			$('.active').addClass('busy');
			$('.active').removeClass('open');
			$('.active').on(transitionend, function (e) {
				$('.active').removeClass('busy');
			});
			$('.active').removeClass('active');
			if (!$('.delete').hasClass('busy')) {
				//hide
				if ($('#pageSlideFood').hasClass("open") && !$('#pageSlideFood').hasClass("busy")) {
					$('#pageSlideFood').addClass('busy');
					$('#pageSlideFood').on(transitionend, function (e) {
						$('#pageSlideFood').removeClass('busy');
						$("#foodSearch").blur();
					});
				} else {
					if (!$('#pageSlideFood').hasClass('busy')) {
						//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						// PAGESLIDEFOOD DIV //
						///////////////////////
						$('#pageSlideFood').remove();
						$('body').append("<div id='pageSlideFood'></div>");
						$('#pageSlideFood').css("height", (window.innerHeight - $('#appHeader').height()) + "px");
						$('#pageSlideFood').css("top", $('#appHeader').height() + "px");
						///////////////
						// CREATE DB //
						///////////////
						clearTimeout(app.vars.pageSlideTimer);
						app.vars.pageSlideTimer = setTimeout(function () {
							$('#pageSlideFood').on(transitionend, function (evt) {
								clearTimeout(app.vars.foodListCloser);
								app.vars.foodListCloser = setTimeout(function() {
									updateFoodDb();
									if($('#pageSlideFood').html() && !$('#pageSlideFood').is(":animated")) {
										$("#appHeader").addClass("closer");
										$("body").addClass("closer");
									}
									setTimeout(function() {
										$('#pageSlideFood').off(transitionend);
									},0);
								},100);
							});
						}, 100);
						///////////////
						// FOOD HTML //
						///////////////
						$("#pageSlideFood").html('<div id="sideMenuFood"><input tabindex="-2" type="text" id="foodSearch" placeholder="' + LANG.FOOD_SEARCH[lang] + '" /><span id="iconClear"></span><span id="iconRefresh" class="icon-refresh"></span><div id="foodListWrapper"><div id="foodList"><span id="noMatches">' + LANG.NO_MATCHES[lang] + '</span></div></div></div>');
						//PRE-ADJUST RESULTS HEIGHT
						$('#foodSearch').width(window.innerWidth - 55);
						buildFoodMenu();
						//remember search type
						if (window.localStorage.getItem("searchType") == "exercise") {
							$("#foodSearch").attr('placeholder', LANG.EXERCISE_SEARCH[lang]);
							$("#foodSearch,#pageSlideFood").addClass("exerciseType");
						}
						////////////////////
						// RESULTS HEIGHT //
						////////////////////
						$('#menuTopBar').css("top", "61px");
						//$('#foodList').css("margin-top","61px");
						$('#foodList').css("min-height", (window.innerHeight - ($('#appHeader').height() + 61)) + "px");
						$('#foodList').css("height", (window.innerHeight - ($('#appHeader').height() + 61)) + "px");
						//$('#foodList').css("top",($('#appHeader').height()) + "px");
						setTimeout(function () {
							getNiceScroll("#foodList");
							$("body").trigger("resize");
						}, 300);
						//SCROLLBAR UPDATE
						clearTimeout(niceTimer);
						niceTimer = setTimeout(niceResizer, 200);
						/////////////
						// handler //
						/////////////
						$("#foodList").scroll(function () {
							//$("body").addClass("closer");
							blockModal = true;
							clearTimeout(modalTimer);
							modalTimer = setTimeout(function () {
									blockModal = false;
								}, 300);
						});
						//#/////////////////////////////////////#//
						//# KEYUP LISTENER SEARCH TIMER-LIMITER #//
						//#/////////////////////////////////////#//
						var timer;
						
						var inputEvent = isMobile.Windows() ? 'keyup' : 'input';
						$("#foodSearch").on(inputEvent,function() {
						//document.getElementById('foodSearch').addEventListener(inputEvent, function () {
							//CLEAR ICON
							if (JSON.stringify($("#foodSearch").val()).length == 0) {
								$('#iconClear').hide();
								$('#iconRefresh').show();
							} else {
								$('#iconRefresh').hide();
								$('#iconClear').show();
							}
							$('#iconClear').on(touchstart, function (evt) {
								clearTimeout(timer);
								$('#foodSearch').val('');
								$('#iconClear').hide();
								$('#iconRefresh').show();
								//buildFoodMenu();
								$('#searchContents').hide();
								$('#infoContents').show();
								$('#menuTopBar').show();
								return false;
							});
							//SET TIMER
							clearTimeout(timer);
							var ms = 200; //275;
							//faster desktop
							if (!app.device.mobile) {
								ms = 50;
							}
							var val = this.value;
							//DO SEARCH
							timer = setTimeout(function () {
									doSearch($("#foodSearch").val());
									//CLEAR ICON
									if ($("#foodSearch").val().length == 0) {
										$('#iconClear').hide();
										$('#iconRefresh').show();
									} else {
										$('#iconRefresh').hide();
										$('#iconClear').show();
									}
								}, ms);
						});
						///////////////////
						// HIDE KEYBOARD //
						///////////////////
						$("#foodList").on(tap, function (evt) {
							evt.preventDefault();
							$("#entryBody").blur();
							$("#foodSearch").blur();
						});
						//////////////////////
						// SEARCH TYPE ICON //
						//////////////////////
						$('#iconRefresh').on(touchstart, function (evt) {
							//toggle -if not animated
							if (!$("#foodSearch").hasClass('busy')) {
								$("#foodSearch").toggleClass("exerciseType");
								$("#pageSlideFood").toggleClass("exerciseType");
								//enforce iconClear
								$('#searchContents').hide();
								$('#menuTopBar').show();
								$('#infoContents').show();
								//update placeholder n' animate
								if ($("#foodSearch").hasClass("exerciseType")) {
									window.localStorage.setItem("searchType", "exercise");
									$("#foodSearch").attr('placeholder', LANG.EXERCISE_SEARCH[lang]);
									$("#foodSearch").addClass('busy');
									$("#foodSearch").animate({
										backgroundColor : "#FECEC6"
									}, 1).animate({
										backgroundColor : "#fff"
									}, 600, function () {
										$("#foodSearch").removeClass('busy');
									});
								} else {
									window.localStorage.removeItem("searchType");
									$("#foodSearch").attr('placeholder', LANG.FOOD_SEARCH[lang]);
									$("#foodSearch").addClass('busy');
									$("#foodSearch").animate({
										backgroundColor : "#BBE4FF"
									}, 1).animate({
										backgroundColor : "#fff"
									}, 600, function () {
										$("#foodSearch").removeClass('busy');
									});
								}
							}
							return false;
						});
						/////////////////////////////////////////
						// FOODSEARCH (QUICKFOCUS) SETOVERFLOW //
						/////////////////////////////////////////
						//$("#foodSearch").on(touchstart, function (evt) {
						//	$(".foodName").css("overflow", "hidden");
						//	$("#activeOverflow").removeAttr("id");
						//	$(".activeOverflow").removeClass("activeOverflow");
						//});
						//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
						//show
						$("#entryBody").blur();
						$("#entryTime").blur();
						//$('#pageSlideFood').css("opacity",".925");
						$('#pageSlideFood').addClass('busy');
						//open directly on first load
						if (window.localStorage.getItem("foodDbLoaded") != "done") {
							$('#pageSlideFood').addClass("open");
						}
						setTimeout(function() {
						//	callbackOpen();
						},0);
						
						$('#loadingDiv').hide();
						$('#appHeader').addClass("open");
						$('#pageSlideFood').on(transitionend, function (e) {
							$('#pageSlideFood').removeClass('busy');
						});
					}
				}
			}
		}
	}
	//#//
}); //#//
//////#//
//#/////////////////#//
//# CORE SQL SEARCH #//
//#/////////////////#//
function searchFood(searchSQL, callback) {
	if (window.localStorage.getItem("searchType") == "exercise") {
		var typeTerm = 'exercise';
	} else {
		var typeTerm = 'food';
	}
	var dato = rowsFood;
	var keyJunk = 0;
	var keyScore = 0;
	var mi = [];
	var limited = 0;
	
	var results = 0;
	var z = dato.length;
	while(z--) {
	//for (var z = 0, len = dato.length; z < len; z++) {
		keyScore = 0;
		keyJunk = 0;
		if (((dato[z].type == "0000" || dato[z].type == "exercise") && typeTerm == "exercise") || ((dato[z].type != "0000" && dato[z].type != "exercise") && typeTerm == "food")) {
			var k = searchSQL.length;
			while(k--) {
			//for (var k = 0, lenn = searchSQL.length; k < lenn; k++) {
				if (dato[z].term.indexOf(searchSQL[k]) != -1 && keyJunk == 0) {
					keyScore = keyScore + Math.abs(dato[z].term.match(searchSQL[k]).index);
				} else {
					keyJunk = 1;
				}
			}
			if (keyJunk == 0) {
				mi.push({
					id : keyScore,
					value : dato[z]
				});
			}
		}
	}
	//SORT
	mi = mi.sortbyattr('id');

	var mou = [];
	for (var u = 0, lenu = mi.length; u < 120; u++) {
		if (mi[u]) {
			mou.push(mi[u].value);
		}
	}
	callback(mou);
}
//#////////////////////////#//
//# SUB FUNCION: DO SEARCH #//
//#////////////////////////#//
function doSearch(rawInput) {
	//ignore null searches
	if (rawInput == 0) {
		rawInput = "00000000";
	}
	/////////////////
	// FETCH INPUT //
	/////////////////
	var timerStart = new Date().getTime();
	var lastSearch = window.localStorage.getItem("lastSearchTerm");
		//sanitize user input
		var searchQuery = trim(rawInput.split("~").join("").split("’").join("").split("”").join("").split("*").join("").split("-").join("").split("(").join("").split(")").join("").split(":").join("").split("/").join("").split("\\").join("").split("&").join("").split("%").join("").split("'").join("").split('"').join("").split(".").join("").split(";").join("").split(',').join(" ").toLowerCase());
		//partial sql syntax
		var searchSQL = searchQuery.split(" ");
		//prevent multiple identical searches
		window.localStorage.setItem("lastSearchTerm", searchQuery);
		//#/////////////////////#//
		//# BUILD KEYWORD ARRAY #//
		//#/////////////////////#//
		var keywordArray = [];
		searchArray = searchQuery;
		//check for multiple keywords
		if (searchQuery.search(' ') > -1) {
			searchQuery = searchQuery.split(" ");
			//loop each key into array
			for (i = 0; i < searchQuery.length; i++) {
				//not null
				if (searchQuery[i] != "") {
					//filter duplicates
					//if($.inArray(trim(searchQuery[i]), keywordArray )) {
					if (keywordArray.indexOf(trim(searchQuery[i])) == -1) {
						keywordArray.push(trim(searchQuery[i]));
					}
				}
			}
		} else {
			//single term array
			keywordArray.push(searchQuery);
		}
	///////////////////////////////////////////////////////////
	// PREVENT EMPTY STRING ON MULTIPLE KEYWORD SEARCH ARRAY //
	///////////////////////////////////////////////////////////
	if (keywordArray != "") {
		//#///////////////#//
		//# QUERY FOOD DB #//
		//#///////////////#//
		var foodList = '';
		var countMatch = 0;
		//ADJUST SEARCH TYPE
		if (window.localStorage.getItem("searchType") == "exercise") {
			//get current weight
			if (!window.localStorage.getItem("calcForm#pA3B")) {
				var totalWeight = 80;
			} else {
				var totalWeight = Number(window.localStorage.getItem("calcForm#pA3B"));
			}
			//convert to kg
			if (window.localStorage.getItem("calcForm#pA3C") == "pounds") {
				var totalWeight = Math.round((totalWeight) / (2.2));
			}
			//TYPES
			var searchType = 'exercise';
		} else {
			var searchType = 'food';
		}
		///////////////////
		// EXECUTE QUERY //
		///////////////////
		searchFood(searchSQL, function (data) {
			// LOOP RESULTS //
			/*
			for (var s = 0, len = data.length; s < len; s++) {
				//total results
				//organize relevant columuns
				var id = data[s].id;
				var type = data[s].type;
				var code = data[s].code;
				var name = data[s].name;
				var term = data[s].term;
				var kcal = Math.round(data[s].kcal * 100) / 100;
				var pro = Math.round(data[s].pro * 100) / 100;
				var car = Math.round(data[s].car * 100) / 100;
				var fat = Math.round(data[s].fat * 100) / 100;
				var fib = 0;
				// SEARCH TYPE //
				var typeClass;
				var favClass = (data[s].fib == "fav") ? 'favItem' : '';
				if (searchType == "exercise") {
					typeClass = " hidden";
					//calculate weight proportion
					kcalBase = kcal;
					kcal = Math.round(((kcal * totalWeight) / 60) * 30);
				} else {
					typeClass = "";
					kcalBase = kcal;
				}
				//html
				var foodLine = "<div class='searcheable " + favClass + "' id='" + code + "' title='" + kcalBase + "'><div class='foodName'>" + name + "</div><span class='foodKcal'><span class='preSpan'>" + LANG.KCAL[lang] + "</span>" + kcal + "</span><span class='foodPro " + typeClass + "'><span class='preSpan'>" + LANG.PRO[lang] + "</span>" + pro + "</span><span class='foodCar " + typeClass + "'><span class='preSpan'>" + LANG.CAR[lang] + "</span>" + car + "</span><span class='foodFat " + typeClass + "'><span class='preSpan'>" + LANG.FAT[lang] + "</span>" + fat + "</span></div>";
				*/
				
				//result list
				//foodList += foodLine;
			//} //end loop
			foodList = app.handlers.buildRows(data.reverse());
			/////////////////////
			// DISPLAY RESULTS //
			/////////////////////
			//matches number
			//$("#iCounter").html(countMatch + " matches");
			$("#menuTopBar").hide();
			$("#infoContents").hide();
			//prevent overflow blinking
			$("#searchContents").hide();
			$("#searchContents").html('');
			//if empty
			//if (foodList == "") {
			if (foodList.contains('noContent')) {
				if ($("#foodSearch").val() != "") {
					$("#searchContents").html('<span id="noMatches"> ' + LANG.NO_MATCHES[lang] + ' </span>');
				} else {
					//buildFoodMenu();
					$('#searchContents').hide();
					$('#menuTopBar').show();
					$('#infoContents').show();
				}
			} else {
				$("#searchContents").html(foodList);
			}
			$("#searchContents").show();
			setTimeout(niceResizer, 200);
			//enforce clearIcon display
			if ($("#foodSearch").val().length != 0) {
				$('#iconRefresh').hide();
				$('#iconClear').show();
			} else {
				$('#iconRefresh').show();
				$('#iconClear').hide();
			}
			////////////////////////
			// OVERFLOW ON-DEMAND //
			////////////////////////
			/*
			$(".searcheable").on(tap + ' ' + touchstart, function (evt) {
				if (blockModal == true) {
					return;
				}
				if ($("#addNewWrapper").html()) {
					return;
				}
				if ($("#foodSearch").is(":focus") && !isDesktop()) {
					//evt.preventDefault();
					//return;
				}
				$("#activeOverflow").removeAttr("id");
				$(".activeOverflow").removeClass("activeOverflow");
				$(this).addClass("activeOverflow");
				$(".foodName", this).attr("id", "activeOverflow");
				$(".foodName").css("overflow", "auto");
			});
			/////////////////////////////////
			// TAP FOOD-ENTRY EDIT (MODAL) //
			/////////////////////////////////
			$("#searchContents div.searcheable").on(singletap, function (event) {
				event.preventDefault();
				if (blockModal == true) {
					return;
				}
				getModalWindow($(this).attr("id"));
			});*/
			app.handlers.activeRow('#searchContents .searcheable','activeOverflow',function(rowId) {
				getModalWindow(rowId);
			});
		});//END QUERY CONTEXT
	}
}
//#//////////////////////#//
//#  UPDATE CUSTOM LIST  #//
//#//////////////////////#//
function updateCustomList(filter, callback) {
	///////////////
	// CORE DATA //
	///////////////
	getCustomList(filter, function (data) {
		//// LOOP RESULTS //
		//var customFavList = "";
		//var customFavSql = "";
		//var favSql;
		//var favLine;
		//var favLastId = '';
		//var c = len = data.length;
		//data = data.reverse();
		/*
		while(c--) {
		//for (var c = 0, len = data.length; c < len; c++) {
			//get current weight//
			if (!window.localStorage.getItem("calcForm#pA3B")) {
				var totalWeight = 80;
			} else {

				var totalWeight = Number(window.localStorage.getItem("calcForm#pA3B"));
			}
			//convert to kg
			if (window.localStorage.getItem("calcForm#pA3C") == "pounds") {
				var totalWeight = Math.round((totalWeight) / (2.2));
			}
			//ADJUST TO EXERCISE
			if (data[c].type == "0000" || data[c].type == "exercise") {
				var cKcal = Math.round(((data[c].kcal * totalWeight) / 60) * 30);
			} else {
				var cKcal = Math.round(data[c].kcal * 100) / 100;
			}
			//cKcal = Math.round(data[c].kcal * 100) / 100;
			cPro = Math.round(data[c].pro * 100) / 100;
			cCar = Math.round(data[c].car * 100) / 100;
			cFat = Math.round(data[c].fat * 100) / 100;
			//////////
			// SYNC //
			//////////
			var id = data[c].id;
			var type = data[c].type;
			var code = data[c].code;
			var name = sanitizeSql(data[c].name);
			var term = data[c].term;
			var kcal = data[c].kcal;
			var pro = data[c].pro;
			var car = data[c].car;
			var fat = data[c].fat;
			var fib = data[c].fib;

			if (!name) {
				name = '0.00';
			}
			if (!kcal) {
				kcal = '0.00';
			}
			if (!pro) {
				pro = '0.00';
			}
			if (!car) {
				car = '0.00';
			}
			if (!fat) {
				fat = '0.00';
			}
			if (!fib) {
				fib = '0.00';
			}

			type = (type == '0000' || type == 'exercise') ? 'exercise' : 'food';
			var favClass = (data[c].fib == "fav") ? 'favItem' : '';

			fib = fib.split("diary_food").join("");

			if (!hasSql && !id) {
				id = data[c].ID;
				if (!data[c].ID) {
					id = 'null';
				}
			}
			///////////////////////////
			if (id && favLastId != id) {
				favSql = "INSERT OR REPLACE INTO \"diary_food\" VALUES(" + id + ",'" + type + "','" + code + "','" + name + "','" + term + "','" + kcal + "','" + pro + "','" + car + "','" + fat + "','" + fib + "');\n";
				customFavSql += favSql;
				favSql = '';
				favLine = "<div class='searcheable " + favClass + " " + type + "' id='" + code + "' title='" + cKcal + "'><div class='foodName " + type + "'>" + name + "</div><span class='foodKcal'><span class='preSpan'>" + LANG.KCAL[lang] + "</span>" + cKcal + "</span><span class='foodPro " + type + "'><span class='preSpan'>" + LANG.PRO[lang] + "</span>" + cPro + "</span><span class='foodCar " + type + "'><span class='preSpan'>" + LANG.CAR[lang] + "</span>" + cCar + "</span><span class='foodFat " + type + "'><span class='preSpan'>" + LANG.FAT[lang] + "</span>" + cFat + "</span></div>";
				customFavList += favLine;
				favLine = ''
					favLastId = id;
			}
		}
		*/
		var customFavList = app.handlers.buildRows(data,filter);
		
		//var sqlKey = (filter == "fav") ? 'customFavSql' : 'customItemsSql';
		//if (customFavList == "") {
		//	customFavList += '<div class="searcheable noContent"><div><em>' + LANG.NO_ENTRIES[lang] + '</em></div></div>';
		//}
		//if (customFavSql != "") {
		//	window.localStorage.setItem(sqlKey, customFavSql.split('undefined').join(''));
		//} else {
		//	window.localStorage.setItem(sqlKey, " ");
		//}
		//////////
		// HTML //
		//////////
		var menuBlock = (filter == 'fav') ? '#tabMyFavsBlock' : '#tabMyItemsBlock';
		//////////
		// HTML //
		//////////
		if (filter != 'fav') {
			customFavList += '<div id="addNewFood">' + LANG.NEW_FOOD[lang] + '</div><div id="addNewExercise">' + LANG.NEW_EXERCISE[lang] + '</div>';
		}
		$(menuBlock).css('min-height', ($('#foodList').height() - 128) + 'px');
		$(menuBlock).html(customFavList);
		/////////////
		// ACTIONS //
		/////////////
		$('#addNewFood').on(touchstart, function (evt) {
			$(this).addClass('active');
			addNewItem({
				type : 'food',
				act : 'insert'
			});
		});
		$('#addNewExercise').on(touchstart, function (evt) {
			$(this).addClass('active');
			addNewItem({
				type : 'exercise',
				act : 'insert'
			});
		});
		//////////////
		// HANDLERS //
		//////////////
		/*
		$(menuBlock + " div.searcheable").on(singletap, function (evt) {
			evt.preventDefault();
			if (blockModal == true) {
				return;
			}
			getModalWindow($(this).attr("id"));
		});
		$(menuBlock + " div.searcheable").on(tap, function (evt) {
			if ($("#foodSearch").is(":focus")) {
				//$("#foodSearch").blur();
				//window.scroll($('#appContent')[0].scrollTop,0,0);
				//return false;
			}
			$("#activeOverflow").removeAttr("id");
			$(".activeOverflow").removeClass("activeOverflow");
			$(this).addClass("activeOverflow");
			$(".foodName", this).attr("id", "activeOverflow");
			$(".foodName").css("overflow", "auto");
		});
		/////////////////////////////////////////
		// FOODSEARCH (QUICKFOCUS) SETOVERFLOW //
		/////////////////////////////////////////
		$(menuBlock + " #foodSearch").on(touchstart, function (evt) {
			if (blockModal == true) {
				return;
			}
			$(".foodName").css("overflow", "hidden");
			$("#activeOverflow").removeAttr("id");
			$(".activeOverflow").removeClass("activeOverflow");
		});
		*/
		app.handlers.activeRow(menuBlock + ' .searcheable','activeOverflow',function(rowId) {
			getModalWindow(rowId);
		});		
		///////////////////
		// CALLBACK OPEN //
		///////////////////
		if (callback == 'open' && window.localStorage.getItem('lastInfoTab') != 'topBarItem-1') {
			setTimeout(function() {
				callbackOpen();
			},0);
		} else {
			if(callback && callback != 'open') {
				callback();
			}
		}
	});
}
//##/////////////////////////////##//
//##    CORE: BUILD FOOD LAYER   ##//
//##/////////////////////////////##//
function buildFoodMenu() {
	var recentBlock = '\
		<div id="infoContents" class="infoContents">\
		<div id="tabMyCats">\
		<div id="tabMyCatsBlock"></div>\
		</div>\
		<div id="tabMyFavs">\
		<div id="tabMyFavsBlock"></div>\
		</div>\
		<div id="tabMyItems">\
		<div id="tabMyItemsBlock"></div>\
		</div>\
		</div>\
		<div id="searchContents"></div>';
	//////////////
	// TOP MENU //
	//////////////
	$("#foodList").before("<div id='menuTopBar'>\
		<h3 id='topBarItem-1'><span>" + LANG.CATEGORIES[lang] + "</span></h3>\
		<h3 id='topBarItem-2'><span>" + LANG.FAVORITES[lang] + "</span></h3>\
		<h3 id='topBarItem-3'><span>" + LANG.MY_ITEMS[lang] + "</span></h3>\
		</div>\
		");
	$("#foodList").html(recentBlock);
	//first load db spinner
	if (window.localStorage.getItem("foodDbLoaded") != "done") {
		//reset blocks
		$("#tabMyCatsBlock,#tabMyFavsBlock,#tabMyItemsBlock").html('<div class="searcheable noContent"><div><em>' + LANG.NO_ENTRIES[lang] + '</em></div></div>');
		$("#addNewFood").remove();
		$("#addNewExercise").remove();
		$("#tabMyItemsBlock").after('<div id="addNewFood">' + LANG.NEW_FOOD[lang] + '</div><div id="addNewExercise">' + LANG.NEW_EXERCISE[lang] + '</div>');
		$('#tabMyItemsBlock').css("min-height", ($('#foodList').height() - 128) + "px");
		//////////////
		// HANDLERS //
		//////////////
		$("#addNewFood").on(touchstart, function (evt) {
			$(this).addClass('active');
			addNewItem({
				type : "food",
				act : "insert"
			});
		});
		$("#addNewExercise").on(touchstart, function (evt) {
			$(this).addClass('active');
			addNewItem({
				type : "exercise",
				act : "insert"
			});
		});
	} else {
		////////////////////
		// CUSTOM FAV SQL //
		////////////////////
		var tabTimer1 = (window.localStorage.getItem("lastInfoTab") == "topBarItem-1") ? 20 : 200;
		var tabTimer2 = (window.localStorage.getItem("lastInfoTab") == "topBarItem-2") ? 20 : 200;
		var tabTimer3 = (window.localStorage.getItem("lastInfoTab") == "topBarItem-3") ? 20 : 200;
		setTimeout(function () {
			getCatList('open');
		}, tabTimer1);
		setTimeout(function () {
			updateCustomList('fav', 'open');
		}, tabTimer2);
		setTimeout(function () {
			updateCustomList('items', 'open');
		}, tabTimer3);
	}
	/////////////////////
	// FIRST LOAD TABS //
	/////////////////////
	if (!window.localStorage.getItem("lastInfoTab")) {
		window.localStorage.setItem("lastInfoTab", "topBarItem-1");
	}
	////////////
	// TAB #1 //
	////////////
	if (window.localStorage.getItem("lastInfoTab") == "topBarItem-1") {
		$("#tabMyCats, #topBarItem-1").addClass("onFocus");
	}
	////////////
	// TAB #2 //
	////////////
	if (window.localStorage.getItem("lastInfoTab") == "topBarItem-2") {
		$("#tabMyFavs, #topBarItem-2").addClass("onFocus");
	}
	////////////
	// TAB #3 //
	////////////
	if (window.localStorage.getItem("lastInfoTab") == "topBarItem-3") {
		$("#tabMyItems, #topBarItem-3").addClass("onFocus");
	}
	////////////////////////
	// SWITCH VISIBLE TAB //
	////////////////////////
	$("#menuTopBar h3").on(touchstart, function (evt) {
		evt.preventDefault();
		$('#foodList').scrollTop(0);
		window.localStorage.setItem("lastInfoTab", $(this).attr("id"));
		//$(".onFocus").removeClass("onFocus");
		//$("#activeOverflow").removeAttr("id");
		$(".activeOverflow").removeClass("activeOverflow");
		//$("#foodList .foodName").css("overflow", "hidden");
		////////////
		// TAB #1 //
		////////////
		if (window.localStorage.getItem("lastInfoTab") == "topBarItem-1") {
			$("#topBarItem-2,#topBarItem-3,#tabMyFavs,#tabMyItems").removeClass("onFocus");
			$("#topBarItem-1,#tabMyCats").addClass("onFocus");
		}
		////////////
		// TAB #2 //
		////////////
		else if (window.localStorage.getItem("lastInfoTab") == "topBarItem-2") {
			$("#topBarItem-1,#topBarItem-3,#tabMyCats,#tabMyItems").removeClass("onFocus");
			$("#topBarItem-2,#tabMyFavs").addClass("onFocus");
		}
		////////////
		// TAB #3 //
		////////////
		else if (window.localStorage.getItem("lastInfoTab") == "topBarItem-3") {
			$("#topBarItem-1,#topBarItem-2,#tabMyCats,#tabMyFavs").removeClass("onFocus");
			$("#topBarItem-3,#tabMyItems").addClass("onFocus");
		}
		clearTimeout(niceTimer);
		niceTimer = setTimeout(function () {
				niceResizer();
				return false;
			}, 0);
		return false;
	});
	/////////////
	// ACTIONS //
	/////////////
	//$(".searcheable").on(tap + ' ' + touchstart, function (evt) {
		//$("#activeOverflow").removeAttr("id");
		//$(this).addClass("activeOverflow");
		//$(".foodName", this).attr("id", "activeOverflow");
		//$(".foodName").css("overflow", "auto");
	//});
}
//##//////////////////////////##//
//##    CORE: ADD NEW ITEM    ##//
//##//////////////////////////##//
function addNewItem(addnew) {
	if (!addnew) {
		return;
	}
	if (!addnew.act) {
		addnew.act = 'update';
	}
	///////////////////
	// PREVENT FLOOD //
	///////////////////
	if($('#addNewWrapper').length) {
		$('#modalWrapper').remove();
	}
	/////////////////////
	// FOOD ? EXERCISE //
	/////////////////////
	addnew.isfoodrow   = (/0000|exercise/).test(addnew.type) ? true : false;
	addnew.totalweight = app.get.totalweight();
	///////////////////////
	// ADDNEW.VALIDATE() //
	///////////////////////
	addnew.validate = function() {
		var isValid = 1;
		$('label').removeClass('error');
		if (addnew.name == '' || addnew.name == 0) {
			$('#addNewName label').addClass('error');
			isValid = 0;
		}
		if (addnew.kcal == '' || addnew.kcal == 0 || isNaN(addnew.kcal)) {
			$('#addNewKcal label').addClass('error');
			isValid = 0;
		}
		if ($('#inputNewAmount').val() == '' || $('#inputNewAmount').val() == 0 || isNaN($('#inputNewAmount').val())) {
			$('#addNewAmount label').addClass('error');
			isValid = 0;
		}
		//RETURN VALID
		if(isValid == true) {
			return true;
		} else {
			//ALERT
			if(hasTouch() && navigator.notification) {
				navigator.notification.alert(LANG.BLANK_FIELD_DIALOG[lang], voidThis, LANG.BLANK_FIELD_TITLE[lang], LANG.OK[lang]);
			} else {
				if (alert(LANG.BLANK_FIELD_TITLE[lang] + "\n" + LANG.BLANK_FIELD_DIALOG[lang]));
			}
			return false;
		}
	};
	////////////////////
	// ADDNEW.CLOSE() //
	////////////////////
	addnew.close = function(evt) {
		if(evt) { 
			evt = evt.target.id;
		} else {
			evt = '';
		}
		//first tap blur, if focused
		if (evt == 'modalOverlay' && $('#addNewWrapper input').is(':focus')) {
			$('#addNewWrapper input').trigger('blur');
			return false;
		}
		if (isMobile.Android()) {
			kickDown();
		}
		$('#addNewExercise, #addNewFood').removeClass('active');
		$('.activeOverflow').removeClass('activeOverflow');
		app.handlers.fade(0,'#modalWrapper');
		clearTimeout(app.repeaterLoop);
	};
	///////////////////
	// ADDNEW.SAVE() //
	///////////////////
	addnew.save = function() {
		//CREATE ID FOR NEW
		if(addnew.act == 'insert') {
			addnew.id   = new Date().getTime();
			addnew.code = 'c' + addnew.id;
			addnew.fib  = 'custom';
		}
		//READ INPUT VALUES
		addnew.name = $('#inputNewName').val();
		addnew.term = sanitize(addnew.name);
		addnew.kcal = $('#inputNewKcal').val();
		addnew.pro  = $('#inputNewPro').val();
		addnew.car  = $('#inputNewCar').val();
		addnew.fat  = $('#inputNewFat').val();
		//REVERT TO FORMULA
		if ((/0000|exercise/).test(addnew.type)) {
			addnew.kcal = Math.round((((addnew.kcal / addnew.totalweight) / $('#inputNewAmount').val()) * 60) * 100) / 100;
		}
		///////////////////
		// VALIDATE FORM //
		///////////////////
		if(!addnew.validate()) {
			//RETURN FALSE ~ REACTIVATE HANDLER
			$('#addNewConfirm').on(touchstart, function (evt) {
				evt.preventDefault();
				evt.stopPropagation();
				$('#addNewConfirm').off(touchstart);
				addnew.save();
			});
			return false;
		}
		/////////////////
		// FORMAT DATA //
		/////////////////
		// IF NULL/EMPTY, JUST REVERT TO 0
		if (addnew.pro == ''|| isNaN(addnew.pro)) {
			addnew.pro = 0;
		}
		if (addnew.car == '' || isNaN(addnew.car)) {
			addnew.car = 0;
		}
		if (addnew.fat == '' || isNaN(addnew.fat)) {
			addnew.fat = 0;
		}
		//revert to 100g
		if (addnew.type == 'food') {
			addnew.kcal = Math.round((addnew.kcal / $('#inputNewAmount').val()) * 100 * 100) / 100;
			addnew.pro  = Math.round((addnew.pro  / $('#inputNewAmount').val()) * 100 * 100) / 100;
			addnew.car  = Math.round((addnew.car  / $('#inputNewAmount').val()) * 100 * 100) / 100;
			addnew.fat  = Math.round((addnew.fat  / $('#inputNewAmount').val()) * 100 * 100) / 100;
			addnew.kcal = Math.round(addnew.kcal);
		} else {
			addnew.kcal = decimalize(addnew.kcal);
		}
		//DECIMALIZE
		addnew.pro = decimalize(addnew.pro);
		addnew.car = decimalize(addnew.car);
		addnew.fat = decimalize(addnew.fat);
		////////////////////
		// SAVE NEW ENTRY //
		////////////////////
		setFood(addnew, function () {
			$('#addNewConfirm').addClass('done');
			////////////
			// UPDATE //
			////////////
			if (addnew.act == 'update') {
				if ((/0000|exercise/).test(addnew.type)) {
					addnew.kcal = Math.round(((addnew.kcal * addnew.totalweight) / 60) * 30);
				}
				//MULTIPLE UNIQUE ~ USE ID AS CLASS
				$('.' + addnew.id + ' .foodName').html(addnew.name);
				$('.' + addnew.id + ' .foodKcal').html('<span class="preSpan">' + LANG.KCAL[lang] + '</span>' + addnew.kcal + '</span>');
				$('.' + addnew.id + ' .foodPro').html('<span class="preSpan">'  + LANG.PRO[lang]  + '</span>' + addnew.pro  + '</span>');
				$('.' + addnew.id + ' .foodCar').html('<span class="preSpan">'  + LANG.CAR[lang]  + '</span>' + addnew.car  + '</span>');
				$('.' + addnew.id + ' .foodFat').html('<span class="preSpan">'  + LANG.FAT[lang]  + '</span>' + addnew.fat  + '</span>');
				//HIGHTLIGHT~CLOSE
				setTimeout(function() {
					addnew.close();
					app.handlers.highlight('.' + addnew.id);
				}, 25);
			} else {
			/////////////////////
			// INSERT NEW ITEM //
			/////////////////////
				updateCustomList('items',function() {
					//HIGHTLIGHT~CLOSE
					setTimeout(function() {
						addnew.close();
						app.handlers.highlight('#' + addnew.id);
					}, 25);
				});
			}
		});
	};
	///////////////
	// CORE HTML //
	///////////////
	var addNewCoreHtml = '\
		<div id="addNewWrapper">\
			<ul id="addNewList">\
				<li id="addNewName">   <label>' + LANG.ADD_NAME[lang] + '</label>                          <input tabindex="3" type="text"   id="inputNewName"                /></li>\
				<li id="addNewAmount"><label>' + LANG.ADD_AMOUNT[lang] + ' (' + LANG.G[lang] + ')</label>  <input tabindex="3" type="number" id="inputNewAmount"  value="100" /></li>\
				<li id="addNewKcal">   <label>' + LANG.KCAL[lang] + '</label>                              <input tabindex="3" type="number" id="inputNewKcal"    value="0"   /></li>\
				<li id="addNewPro">    <label>' + LANG.PRO[lang] + '</label>                               <input tabindex="3" type="number" id="inputNewPro"     value="0"   /></li>\
				<li id="addNewCar">    <label>' + LANG.CAR[lang] + '</label>                               <input tabindex="3" type="number" id="inputNewCar"     value="0"   /></li>\
				<li id="addNewFat">    <label>' + LANG.FAT[lang] + '</label>                               <input tabindex="3" type="number" id="inputNewFat"     value="0"   /></li>\
			</ul>\
			<div id="addNewCancel">' + LANG.CANCEL[lang] + '</div>\
			<div id="addNewConfirm">' + LANG.SAVE[lang] + '</div>\
		</div>\
	';
	//////////////////////////////
	// INSERT ? UPDATE WRAPPER //
	//////////////////////////////
	if($('#modalWrapper').length) {
		$('#modalWrapper').append(addNewCoreHtml);
		$('#addNewWrapper').hide();
		app.handlers.fade(0,'#modalWindow',function() {
			app.handlers.fade(1,'#addNewWrapper');
		});
	} else {
		//CREATE NEW
		$('body').append('<div id="modalWrapper"><div id="modalOverlay"></div>' + addNewCoreHtml + '</div>');
		$('#modalWrapper').show();
		$('#addNewWrapper').show();
		app.handlers.fade(1,'#modalWrapper');
		app.handlers.fade(1,'#addNewWrapper');
	}			
	/////////////////////
	// POPULATE INPUTS //
	/////////////////////
	if (addnew.act == 'update') {
		$('#inputNewName').val(addnew.name);
		$('#inputNewKcal').val(Math.round(addnew.kcal))
		$('#inputNewPro').val(addnew.pro);
		$('#inputNewCar').val(addnew.car);
		$('#inputNewFat').val(addnew.fat);
	}
	/////////////////////////////
	// ADJUST FORM TO EXERCISE //
	/////////////////////////////
	if ((/0000|exercise/).test(addnew.type)) {
		$('#addNewAmount label').html(LANG.ADD_DURATION[lang] + ' (' + LANG.MIN[lang] + ')');
		$('#inputNewAmount').val(30);
		$('#addNewPro').hide();
		$('#addNewCar').hide();
		$('#addNewFat').hide();
		if (addnew.act == 'update') {
			$('#inputNewKcal').val(Math.round(((addnew.kcal * addnew.totalweight) / 60) * $('#inputNewAmount').val()));
		}
	}
	////////////////
	// SET STYLES //
	////////////////
	$('ul#addNewList input').width(window.innerWidth - 180);
	///////////////////////////////////////////
	// android input blur blank viewport bug //
	///////////////////////////////////////////
	if (isMobile.Android()) {
		//preset wrapper min-height
		$('#addNewWrapper').css('min-height', $('#addNewWrapper').height() + 'px');
		//trigger on touchmove if not focused (closing-touch white gap)
		$('#addNewWrapper').on('touchmove', function (evt) {
			if (!$('#addNewWrapper input').is(':focus')) {
				$(window).trigger('orientationchange');
			}
		});
		//trigger if not focused to another input
		var newBlurGap;
		$('#addNewWrapper input').on('blur', function (evt) {
			newBlurGap = setTimeout(function () {
				$(window).trigger("orientationchange");
			}, 100);
		});
		$('#addNewWrapper input').on('focus', function (evt) {
			clearTimeout(newBlurGap);
		});
	}
	///////////////////////////
	// autohide keyboard tap //
	///////////////////////////
	$('#addNewWrapper').on(touchstart, function (evt) {
		if (evt.target.id == 'addNewWrapper' || evt.target.id == '') {
			evt.preventDefault();
			evt.stopPropagation();
			$('#addNewWrapper input').trigger('blur');
		}
	});
	/////////////////////
	// AUTO EMPTY IF 0 //
	/////////////////////
	$('#addNewWrapper input[type="number"]').on('focus', function (evt) {
		if ($(this).val() == 0) {
			$(this).val('');
		}
	});
	$('#addNewWrapper input[type="number"]').on('blur', function (evt) {
		if ($(this).val() == '') {
			$(this).val('0');
		}
	});
	////////////////
	// VALIDATION //
	////////////////
	app.handlers.validate('#addNewWrapper input[type="number"]',{maxLength:7,allowDots:1});
	//////////////
	// HANDLERS //
	//////////////
	//CLOSE
	$('#addNewCancel').on(touchstart, function (evt) {
		evt.stopPropagation();
		addnew.close(evt);
		return false;
	});
	//SAVE
	$('#addNewConfirm').on(touchstart, function (evt) {
		evt.stopPropagation();
		$('#addNewConfirm').off(touchstart);
		addnew.save();
		return false;
	});
}
//#////////////////////#//
//#    MODAL WINDOW    #//
//#////////////////////#//
function getModalWindow(itemId) {
	if (!itemId) {
		return;
	}
	///////////////////
	// PREVENT FLOOD //
	///////////////////
	$('#modalWrapper').remove();
	$('#addNewWrapper').remove();
	//////////////
	// GET DATA //
	//////////////
	var modal = {};
	getFood(itemId, function (data) {
		modal = {
			id  : itemId,
			name: data.name,
			type: data.type,
			code: data.code,
			term: data.term,
			kcal: decimalize(data.kcal),
			pro : decimalize(data.pro),
			car : decimalize(data.car),
			fat : decimalize(data.fat),
			fib : data.fib
		};
		/////////////////////
		// FOOD ? EXERCISE //
		/////////////////////
		var isFoodRow = (modal.type != '0000' && modal.type != 'exercise') ? true : false;
		var totalWeight = window.localStorage.getItem('calcForm#pA3B') ? parseInt(window.localStorage.getItem('calcForm#pA3B')) : 80;
		if (window.localStorage.getItem('calcForm#pA3C') == 'pounds') {
			totalWeight = Math.round((totalWeight) / (2.2));
		}
		/////////////////////////////
		// MODAL.UPDATENUTRIENTS() //
		/////////////////////////////
		modal.updatenutrients = function() {
			if (isFoodRow) {
				var modalAmount = parseInt($("#modalAmount").html());
				$('#proData p').html(decimalize((modal.pro/100)*modalAmount,1));
				$('#carData p').html(decimalize((modal.car/100)*modalAmount,1));				
				$('#fatData p').html(decimalize((modal.fat/100)*modalAmount,1));				
			}
		}
		/////////////////////////
		// MODAL.CHECKACTIVE() //
		/////////////////////////
		modal.checkactive = function() {
			if(parseInt($('#modalTotal').html()) != 0) {
				if(!$('#modalOk').hasClass('active')) {
					$('#modalOk').addClass('active');
				}
			} else {
				$('#modalOk').removeClass('active');
			}
		};
		/////////////////
		// MODAL.ADD() //
		/////////////////
		modal.add = function() {
			if (isFoodRow) {
				//FOOD
				var modalAmount = parseInt($("#modalAmount").html()) + 5;
				var modalTotal  = Math.round((modal.kcal / 100) * modalAmount);
				if (modalAmount < 750 && modalTotal <= 9999) {
					$("#modalAmount").html(modalAmount);
					$("#modalTotal").html(modalTotal);
					modal.updatenutrients();
					modal.checkactive();
				}
			} else {
				//EXERCISE
				var modalAmount = parseInt($("#modalAmount").html()) + 1;
				var modalTotal  = Math.round(((modal.kcal * totalWeight) / 60) * modalAmount)
				if (modalAmount < 360 && modalTotal <= 9999) {
					$("#modalAmount").html(modalAmount);
					$("#modalTotal").html(modalTotal);
					modal.checkactive();
				}
			}
		};
		/////////////////
		// MODAL.REM() //
		/////////////////
		modal.rem = function() {
			if (isFoodRow) {
				//FOOD
				var modalAmount = parseInt($("#modalAmount").html()) - 5;
				var modalTotal  = Math.round((modal.kcal / 100) * modalAmount);
				if (modalAmount >= 0) {
					$("#modalAmount").html(modalAmount);
					$("#modalTotal").html(modalTotal);
					modal.updatenutrients();
					modal.checkactive();
				}
			} else {
				//EXERCISE
				var modalAmount = parseInt($("#modalAmount").html()) - 1;
				var modalTotal  = Math.round(((modal.kcal * totalWeight) / 60) * modalAmount)
				if (modalAmount >= 0) {
					$("#modalAmount").html(modalAmount);
					$("#modalTotal").html(modalTotal);
					modal.checkactive();
				}
			}
		};
		///////////////////
		// MODAL.CLOSE() //
		///////////////////
		modal.close = function(published) {
			app.handlers.fade(0,'#modalWrapper',function() {
				if(published) {
					updateTimer();
					setTimeout(function() {
						app.exec.updateEntries(published);
						updateEntriesTime();
						updateEntriesSum();
						intakeHistory();
						setPush();
					}, 1000);
				}	
			});
			$('.activeOverflow').removeClass('activeOverflow');
			clearTimeout(app.repeaterLoop);
		};
		//////////////////
		// MODAL.SAVE() //
		//////////////////
		modal.save = function() {
			/////////////////////
			// FOOD ? EXERCISE //
			/////////////////////
			var saveTitle = isFoodRow ? parseInt($('#modalTotal').html()) : parseInt($('#modalTotal').html()) * -1;
			var saveUnit  = isFoodRow ? LANG.G[lang] : ' ' + LANG.MIN[lang];
			var saveBody  = modal.name + ' (' + $('#modalAmount').html() + saveUnit + ')';
			////////////////
			// ENTRY TIME //
			////////////////
			var saveTime = new Date().getTime();
			if (Number($('#entryTime').val()) >= 1) {
				saveTime = saveTime - (Number($('#entryTime').val()) * (60 * 60 * 1000));
			}
			///////////////
			// ADD ENTRY //
			///////////////
			saveEntry({
				title     : saveTitle,
				body      : saveBody,
				published : saveTime,
				type      : modal.type,
				pro       : parseFloat($("#proData p").html()),
				car       : parseFloat($("#carData p").html()),
				fat       : parseFloat($("#fatData p").html())
			},function() {
				$('#addNewConfirm').addClass('done');
				//////////////
				// CALLBACK //
				//////////////
				//AUTO START
				if (window.localStorage.getItem('appStatus') != 'running') {
					appConfirm(LANG.NOT_RUNNING_TITLE[lang], LANG.NOT_RUNNING_DIALOG[lang], function(button) {
						if (button == 1) {
							window.localStorage.setItem('config_start_time', saveTime);
							window.localStorage.setItem('appStatus', 'running');
							$('#appStatusTitle').html(LANG.RESET[lang]);
							$('#appStatus').removeClass('start');
							$('#appStatus').addClass('reset');
							app.exec.updateEntries(saveTime);
							setPush();
						}
					}, LANG.OK[lang], LANG.CANCEL[lang]);
				}
				setTimeout(function() {
					//FADE OUT
					modal.close(saveTime);
					//HIGHLIGHT
					app.handlers.highlight('.' + modal.id);
				},25);
			});
		};
		/////////////////
		// MODAL.FAV() //
		/////////////////
		modal.fav = function() {
			//TOGGLE STYLE
			if($('.' + modal.id).hasClass('favItem')) {
				$('.' + modal.id).removeClass('favItem');
				$('#modalFav').removeClass('favorite');
				modal.fib = 'nonFav';
			} else {
				$('.' + modal.id).addClass('favItem');
				$('#modalFav').addClass('favorite');
				modal.fib = 'fav';
			}
			//UPDATE DB
			setFav(modal,function() {
				updateCustomList('fav');
			});
		};
		////////////////////
		// MODAL.REMOVE() //
		////////////////////
		modal.remove = function() {
			appConfirm(LANG.DELETE_ITEM[lang], LANG.ARE_YOU_SURE[lang], function(button) {
				if (button == 1) {
					modal.close();			
					setTimeout(function() {
						delFood(modal.id,function() {
							$('.' + modal.id).each(function(row) {
								if ($('#' + $(this).parent('div').attr('id') + ' .searcheable').length == 1) {
									$(this).parent('div').append('<div class="searcheable noContent"><div><em>' + LANG.NO_ENTRIES[lang] + '</em></div></div>');
								}
								$('#' + $(this).parent('div').attr('id') + ' .' + modal.id).remove();
							});
						});
					},100);
				}
			}, LANG.OK[lang], LANG.CANCEL[lang]);
		};
		/////////////////////
		// MODAL.PREFILL() //
		/////////////////////
		modal.prefill = function() {
			$('#appContent').show();
			$('#modalContent span').addClass('active');
			modal.close();
			setTimeout(function() {
				appFooter('tab2',1,function() {
					$("#entryBody").val(modal.name);
					setTimeout(function () {
						$('#appHeader').trigger(touchstart);
					}, 300);
					$('#entryBody').width(window.innerWidth - 58);
					highlight('#entryBody');
				});
			},0);
		};
		////////////////
		// HTML FRAME //
		////////////////
		$('body').append('\
		<div id="modalWrapper">\
			<div id="modalOverlay"></div>\
			<div id="modalWindow">\
				<div id="modalDelete"></div>\
				<div id="modalEdit"></div>\
				<div id="modalFav"></div>\
				<div id="modalContent">' + modal.name + '&nbsp; <span>&nbsp;' + LANG.PRE_FILL[lang] + '</span></div>\
				<div id="modalButtons">\
					<span id="modalOk">'     + LANG.ADD[lang]    + '</span>\
					<span id="modalCancel">' + LANG.CANCEL[lang] + '</span>\
				</div>\
				<div id="modalAdjust">\
					<span id="modalNegBlock"><span id="modalNeg"></span></span>\
					<span id="modalPosBlock"><span id="modalPos"></span></span>\
					<span id="modalAmountBlock"><span id="modalAmount">0</span><span id="modalAmountType">' + LANG.MINUTES[lang] + '</span></span>\
					<span id="modalTotalBlock"><span id="modalTotal">0</span><span id="modalTotalType">'    + LANG.KCAL[lang]    + '</span></span>\
				</div>\
			</div>\
		</div>');
		////////////////////
		// + FOOD DETAILS //
		////////////////////
		if (isFoodRow) {
			$('#modalAmountType').html(LANG.GRAMS[lang]);
			$('#modalTotalType').after("\
				<span id='proData'><p>0.0</p><span>" + LANG.G[lang] + "</span></span>\
				<span id='carData'><p>0.0</p><span>" + LANG.G[lang] + "</span></span>\
				<span id='fatData'><p>0.0</p><span>" + LANG.G[lang] + "</span></span>\
				<span id='proLabel'>" + LANG.PRO[lang] + "</span>\
				<span id='carLabel'>" + LANG.CAR[lang] + "</span>\
				<span id='fatLabel'>" + LANG.FAT[lang] + "</span>\
			");
		}
		//READ STORED
		if (modal.fib == 'fav') {
			$('#modalFav').addClass('favorite');
		}		
		//////////
		// SHOW //
		//////////
		app.handlers.fade(1,'#modalWrapper',function() {
			//////////////
			// HANDLERS //
			//////////////
			//FIX PROPAGATION
			$('#modalWindow').on(touchmove, function (evt) {
				evt.preventDefault();
				evt.stopPropagation();
			});
			if (isMobile.Windows()) {
				$('#modalWindow').on(touchstart, function (evt) {
					evt.stopPropagation();
				});
			}
			//REPEATERS
			app.handlers.repeater('#modalPosBlock','active',400,50,function() {
				modal.add();
			});
			app.handlers.repeater('#modalNegBlock','active',400,50,function() {
				modal.rem();
			});
			//SAVE
			$('#modalOk').on(touchstart, function (evt) {
				evt.preventDefault();
				evt.stopPropagation();
				if(parseInt($('#modalTotal').html()) != 0) {
					$('#modalOk').off();				
					modal.save();				
				}
				return false;
			});
			//CANCEL
			$('#modalOverlay, #modalCancel').on(touchstart, function (evt) {
				evt.preventDefault();
				evt.stopPropagation();
				modal.close();
				return false;
			});
			//EDIT
			$('#modalEdit').on(touchend, function (evt) {
			//app.handlers.activeRow('#modalEdit','active',function(targetId) {
				evt.preventDefault();
				evt.stopPropagation();
				addNewItem(modal);
				return false;
			});
			//FAV
			$('#modalFav').on(touchend, function (evt) {
			//app.handlers.activeRow('#modalFav','active',function(targetId) {
				evt.preventDefault();
				evt.stopPropagation();
				modal.fav();
				return false;
			});
			//DELETE
			$('#modalDelete').on(touchend, function (evt) {
			//app.handlers.activeRow('#modalDelete','active',function(targetId) {
				evt.preventDefault();
				evt.stopPropagation();
				modal.remove();
				return false;
			});
			//PREFILL
			$('#modalContent').on(touchend, function (evt) {
			//app.handlers.activeRow('#modalContent','active',function(targetId) {
				evt.preventDefault();
				evt.stopPropagation();
				modal.prefill();
				return false;
			});
		});
	});
}

