﻿var mi = {
	RECENT_ENTRIES : {
		en : 'Recent entries',
		pt : 'Entradas recentes',
		ar : '',
		bg : '',
		ca : '',
		cs : '',
		da : '',
		de : '',
		el : '',
		es : '',
		et : '',
		fa : '',
		fi : '',
		fr : '',
		hi : '',
		hr : '',
		hu : '',
		it : '',
		id : '',
		iw : '',
		ja : '',
		ko : '',
		lt : '',
		lv : '',
		ms : '',
		nl : '',
		nb : '',
		pl : '',
		ro : '',
		ru : '',
		sk : '',
		sl : '',
		sr : '',
		sv : '',
		th : '',
		tr : '',
		uk : '',
		vi : '',
		zh : '',
		zt : '',
	},
	ALL_TIME : {
		en : '',
		pt : '',
		ar : '',
		bg : '',
		ca : '',
		cs : '',
		da : '',
		de : '',
		el : '',
		es : '',
		et : '',
		fa : '',
		fi : '',
		fr : '',
		hi : '',
		hr : '',
		hu : '',
		it : '',
		id : '',
		iw : '',
		ja : '',
		ko : '',
		lt : '',
		lv : '',
		ms : '',
		nl : '',
		nb : '',
		pl : '',
		ro : '',
		ru : '',
		sk : '',
		sl : '',
		sr : '',
		sv : '',
		th : '',
		tr : '',
		uk : '',
		vi : '',
		zh : '',
		zt : '',
	},
	XXX : {
		en : '',
		pt : '',
		ar : '',
		bg : '',
		ca : '',
		cs : '',
		da : '',
		de : '',
		el : '',
		es : '',
		et : '',
		fa : '',
		fi : '',
		fr : '',
		hi : '',
		hr : '',
		hu : '',
		it : '',
		id : '',
		iw : '',
		ja : '',
		ko : '',
		lt : '',
		lv : '',
		ms : '',
		nl : '',
		nb : '',
		pl : '',
		ro : '',
		ru : '',
		sk : '',
		sl : '',
		sr : '',
		sv : '',
		th : '',
		tr : '',
		uk : '',
		vi : '',
		zh : '',
		zt : '',
	},
	XXX : {
		en : '',
		pt : '',
		ar : '',
		bg : '',
		ca : '',
		cs : '',
		da : '',
		de : '',
		el : '',
		es : '',
		et : '',
		fa : '',
		fi : '',
		fr : '',
		hi : '',
		hr : '',
		hu : '',
		it : '',
		id : '',
		iw : '',
		ja : '',
		ko : '',
		lt : '',
		lv : '',
		ms : '',
		nl : '',
		nb : '',
		pl : '',
		ro : '',
		ru : '',
		sk : '',
		sl : '',
		sr : '',
		sv : '',
		th : '',
		tr : '',
		uk : '',
		vi : '',
		zh : '',
		zt : '',
	},
	XXX : {
		en : '',
		pt : '',
		ar : '',
		bg : '',
		ca : '',
		cs : '',
		da : '',
		de : '',
		el : '',
		es : '',
		et : '',
		fa : '',
		fi : '',
		fr : '',
		hi : '',
		hr : '',
		hu : '',
		it : '',
		id : '',
		iw : '',
		ja : '',
		ko : '',
		lt : '',
		lv : '',
		ms : '',
		nl : '',
		nb : '',
		pl : '',
		ro : '',
		ru : '',
		sk : '',
		sl : '',
		sr : '',
		sv : '',
		th : '',
		tr : '',
		uk : '',
		vi : '',
		zh : '',
		zt : '',
	},
	XXX : {
		en : '',
		pt : '',
		ar : '',
		bg : '',
		ca : '',
		cs : '',
		da : '',
		de : '',
		el : '',
		es : '',
		et : '',
		fa : '',
		fi : '',
		fr : '',
		hi : '',
		hr : '',
		hu : '',
		it : '',
		id : '',
		iw : '',
		ja : '',
		ko : '',
		lt : '',
		lv : '',
		ms : '',
		nl : '',
		nb : '',
		pl : '',
		ro : '',
		ru : '',
		sk : '',
		sl : '',
		sr : '',
		sv : '',
		th : '',
		tr : '',
		uk : '',
		vi : '',
		zh : '',
		zt : '',
	},
	XXX : {
		en : '',
		pt : '',
		ar : '',
		bg : '',
		ca : '',
		cs : '',
		da : '',
		de : '',
		el : '',
		es : '',
		et : '',
		fa : '',
		fi : '',
		fr : '',
		hi : '',
		hr : '',
		hu : '',
		it : '',
		id : '',
		iw : '',
		ja : '',
		ko : '',
		lt : '',
		lv : '',
		ms : '',
		nl : '',
		nb : '',
		pl : '',
		ro : '',
		ru : '',
		sk : '',
		sl : '',
		sr : '',
		sv : '',
		th : '',
		tr : '',
		uk : '',
		vi : '',
		zh : '',
		zt : '',
	},
};
//’ ✓
















/*



<input id="demo" placeholder="Please Select ..." />

<button id="clear">Clear</button>
<button id="show">Show</button>
Javascript
Copy to Clipboard

$(function(){
    $('#demo').mobiscroll().number({
        theme: 'mobiscroll',
        display: 'bottom',
        mode: 'scroller',
        animate: 'none',
        layout: 'fixed',
        step: 1,
        min: 1,
        max: 15,
        fixedWidth: 150
    });    
    $('#show').click(function(){
        $('#demo').mobiscroll('show'); 
        return false;
    });
    $('#clear').click(function () {
        $('#demo').val('');
        return false;
    });
});














<select name="City" id="demo">
    <option value="1">Atlanta</option>
    <option value="2">Berlin</option>
    <option value="3">Boston</option>
    <option value="4">Chicago</option>
    <option value="5">London</option>
    <option value="6">Los Angeles</option>
    <option value="7">New York</option>
    <option value="8">Paris</option>
    <option value="9">San Francisco</option>
</select>

<button id="clear">Clear</button>
<button id="show">Show</button>



$(function(){
    $('#demo').mobiscroll().select({
        theme: 'mobiscroll',
        display: 'bottom',
        animate: 'none',
        mode: 'scroller',
        minWidth: 200
    });

    $('#show').click(function () {
        $('#demo').mobiscroll('show'); 
        return false;
    });

    $('#clear').click(function () {
        $('#demo').val(1).change();
        return false;
    });
});



*/

